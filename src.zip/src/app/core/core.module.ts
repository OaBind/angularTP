import {NgModule} from '@angular/core';
import { HomeComponentComponent } from './components/home-component/home-component.component';
import { HomeComponent } from './components/home/home.component';

@NgModule({
  declarations: [HomeComponentComponent, HomeComponent],
  imports: [],
  exports: [],
  providers: []
})

export class CoreModule {}
